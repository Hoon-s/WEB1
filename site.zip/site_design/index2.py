import requests
from bs4 import BeautifulSoup
q='실험'

req = requests.get('https://search.naver.com/search.naver?query={}'.format(q))
html = req.text
soup = BeautifulSoup(html, 'html.parser')
my_titles = soup.find_all('dl')
for titles in my_titles:
    if titles.find('a'):
        print(titles.find('a').text)
#list_text=[]
#for title in my_titles:
 #   list_text.append({'text':title.find('a').get_text(), 'link':title.get('href')})