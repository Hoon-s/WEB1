from django.shortcuts import render

def index(request):
    return render(request,'main/index.html')

def addview(request):
    return render(request,'main/index1.html')
                  
def deleteview(request):
    return render(request,'main/index2.html')

def inquiryview(request):
    return render(request,'main/index3.html')

def communityview(request):
    return render(request,'main/index4.html')

def helpview(request):
    return render(request,'main/index.html')
