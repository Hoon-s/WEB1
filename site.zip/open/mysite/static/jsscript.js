function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

var setCookie = function(name, value, exp) {
    var date = new Date();
    date.setTime(date.getTime() + exp*24*60*60*1000);
    document.cookie = name + '=' + value + ';expires=' + date.toUTCString() + ';path=/';
};


var getCookie = function(name) {
    var value = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
    return value? value[2] : null;
};

var deleteCookie = function(name) {
    document.cookie = name + '=; expires=Thu, 01 Jan 1999 00:00:10 GMT;';
};
var search_site=["naver","daum","zum","google","yahoo"]
function submit_cookie(){
    var chkbox = document.getElementsByName('search');
    for(var i=0 ; i<chkbox.length ; i++) { 
        if(chkbox[i].checked) { 
            setCookie(search_site[i],"True",36500)
        }
    }
}
function delete_cookie(){
    var chkbox = document.getElementsByName('search');
    for(var i=0 ; i<chkbox.length ; i++) { 
        if(chkbox[i].checked) { 
            deleteCookie(search_site[i])
        }
    }
}

function doDisplay(){
    for(var i=0;i<5;++i){
        var con = document.getElementById(search_site[i]);
        if(getCookie(search_site[i])=='True'){
            con.style.display = 'block';
        }else{
            con.style.display = 'none';
        }
    }
    
}
