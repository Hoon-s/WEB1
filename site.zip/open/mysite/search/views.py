from django.shortcuts import render
import requests
from bs4 import BeautifulSoup

def searchnaver(request):
    q=request.GET['query']

    req = requests.get('https://search.naver.com/search.naver?query={}'.format(q))
    html = req.text
    soup = BeautifulSoup(html, 'html.parser')
    my_titles = soup.find_all('dl')
    list_text=[]
    for title in my_titles:
        if title.select_one('ul>li>dl>dt>a'):
            text=title.select_one('ul>li>dl>dt>a').text
            link=title.select_one('ul>li>dl>dt>a').get('href')
            information=title.select('ul>li>dl>dd')[1].text
            list_text.append({'text':text, 'link':link, 'info':information})
    context={'list1':list_text, 'q':q}
    return render(request, "search/index.html",context)


headers_Get = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:49.0) Gecko/20100101 Firefox/49.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1'
    }


def searchgoogle(request):
    q=request.GET['query']
    s = requests.Session()
    url = 'https://www.google.com/search?q=' + q + '&ie=utf-8&oe=utf-8'
    r = s.get(url, headers=headers_Get)

    soup = BeautifulSoup(r.text, "html.parser")
    output = []
    for searchWrapper in soup.find_all('div', {'class':'rc'}): #this line may change in future based on google's web page structure
        url = searchWrapper.find('div', {'class':'r'}).find('a')["href"] 
        text = searchWrapper.find('div', {'class':'r'}).find('a').find('h3').text.strip()
        information = searchWrapper.find('div', {'class':'s'}).find('div').text.strip()
        result = {'text': text, 'link': url, 'info':information}
        output.append(result)
        print(result)
    context={'list1':output, 'q':q}
    return render(request, "search/index.html",context)

def searchdaum(request):
    q=request.GET['query']

    req = requests.get('https://search.daum.net/search?q={}'.format(q))
    html = req.text
    soup = BeautifulSoup(html, 'html.parser')
    my_titles = soup.select('div > ul > li > div > div')
    print(my_titles)
    list_text=[]
    for title in my_titles:
        if title.select_one('div>a') and title.select_one('p'):
            text=title.select_one('div>a').text
            link=title.select_one('div>a').get('href')
            information=title.select_one('p').text
            list_text.append({'text':text, 'link':link, 'info':information})
    context={'list1':list_text, 'q':q}
    print(context)
    return render(request, "search/index.html",context)

def searchyahoo(request):
    q=request.GET['query']

    req = requests.get('http://search.zum.com/search.zum?query={}'.format(q))
    html = req.text
    soup = BeautifulSoup(html, 'html.parser')
    my_titles = soup.select('div > div > div > div> div> div > div > div> div> div> div')
    print(my_titles)
    list_text=[]
    for title in my_titles:
        if title.select_one('div>a') and title.select_one('div'):
            text=title.select_one('div>a').text
            link=title.select_one('div>a').get('href')
            information=title.select_one('div').text
            list_text.append({'text':text, 'link':link, 'info':information})
    context={'list1':list_text, 'q':q}
    return render(request, "search/index.html",context)

def searchzum(request):
    q=request.GET['query']

    req = requests.get('http://search.zum.com/search.zum?query={}'.format(q))
    html = req.text
    soup = BeautifulSoup(html, 'html.parser')
    my_titles = soup.select('div > div > div > div> div> div > div > div> div> div> div')
    print(my_titles)
    list_text=[]
    for title in my_titles:
        if title.select_one('div>a') and title.select_one('div'):
            text=title.select_one('div>a').text
            link=title.select_one('div>a').get('href')
            information=title.select_one('div').text
            list_text.append({'text':text, 'link':link, 'info':information})
    context={'list1':list_text, 'q':q}
    return render(request, "search/index.html",context)

